import pandas as pd
from pybit.unified_trading import HTTP
from config import API_KEY, API_SECRET, TESTNET, LEVERAGE, MAX_POSITION_USDT


def get_client() -> HTTP:
    return HTTP(
        testnet=TESTNET,
        api_key=API_KEY,
        api_secret=API_SECRET,
    )


def get_candles(client: HTTP, symbol: str, interval: str, limit: int = 100) -> pd.DataFrame:
    """Fetch OHLCV candles and return as DataFrame."""
    resp = client.get_kline(
        category="linear",
        symbol=symbol,
        interval=interval,
        limit=limit,
    )
    data = resp["result"]["list"]
    df = pd.DataFrame(data, columns=["timestamp", "open", "high", "low", "close", "volume", "turnover"])
    df = df.astype({"open": float, "high": float, "low": float, "close": float, "volume": float})
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


def set_leverage(client: HTTP, symbol: str):
    """Set leverage for a symbol."""
    try:
        client.set_leverage(
            category="linear",
            symbol=symbol,
            buyLeverage=str(LEVERAGE),
            sellLeverage=str(LEVERAGE),
        )
    except Exception as e:
        # Already set or not needed
        print(f"  Leverage set skipped for {symbol}: {e}")


def get_open_positions(client: HTTP, symbol: str) -> list:
    """Return open positions for a symbol."""
    resp = client.get_positions(category="linear", symbol=symbol)
    return [p for p in resp["result"]["list"] if float(p.get("size", 0)) > 0]


def calculate_qty(price: float, symbol: str) -> float:
    """Calculate order quantity based on MAX_POSITION_USDT and leverage."""
    notional = MAX_POSITION_USDT * LEVERAGE
    qty = notional / price
    # Round to reasonable precision
    if price > 10000:   # BTC
        qty = round(qty, 3)
    elif price > 100:   # ETH, SOL high
        qty = round(qty, 2)
    else:
        qty = round(qty, 1)
    return qty


def place_order(client: HTTP, symbol: str, side: str, price: float,
                stop_loss_pct: float, take_profit_pct: float) -> dict:
    """Place a market order with SL and TP."""
    set_leverage(client, symbol)
    qty = calculate_qty(price, symbol)

    if side == "long":
        order_side = "Buy"
        sl_price = round(price * (1 - stop_loss_pct), 2)
        tp_price = round(price * (1 + take_profit_pct), 2)
    else:
        order_side = "Sell"
        sl_price = round(price * (1 + stop_loss_pct), 2)
        tp_price = round(price * (1 - take_profit_pct), 2)

    resp = client.place_order(
        category="linear",
        symbol=symbol,
        side=order_side,
        orderType="Market",
        qty=str(qty),
        stopLoss=str(sl_price),
        takeProfit=str(tp_price),
        timeInForce="GTC",
    )
    return {
        "symbol": symbol,
        "side": side,
        "qty": qty,
        "entry_price": price,
        "stop_loss": sl_price,
        "take_profit": tp_price,
        "order_id": resp["result"].get("orderId"),
    }
