# BTC Trading Bot 🤖

Automated trading bot für Bybit — BTC, ETH, SOL mit EMA Crossover + RSI Strategie.

## Setup

```bash
cd btc-bot
python3 -m venv venv
source venv/bin/activate
pip install pybit pandas ta python-dotenv

cp .env.example .env
# .env bearbeiten und API Keys eintragen
```

## Konfiguration (.env)

```
BYBIT_API_KEY=dein_key
BYBIT_API_SECRET=dein_secret
BYBIT_TESTNET=true   # auf false setzen für echtes Geld!
```

## Starten

```bash
source venv/bin/activate
python bot.py
```

## Strategie

- **EMA 9/21 Crossover** — Einstiegssignal
- **RSI Filter (40–65)** — verhindert Trades bei Überkauf/Überverkauf
- **Multi-Token Auswahl** — BTC, ETH, SOL werden verglichen, stärkstes Signal gewinnt
- **Max. 1 offene Position** gleichzeitig

## Parameter

| Parameter | Wert |
|-----------|------|
| Leverage | 10x |
| Max. Einsatz | $150 |
| Stop Loss | 15% |
| Take Profit | 30% |
| Candle Interval | 15 Min |
| Check Interval | 60 Sek |

## Dateien

- `bot.py` — Hauptprogramm
- `strategy.py` — Signalberechnung
- `exchange.py` — Bybit API
- `config.py` — Alle Parameter
- `bot.log` — Logdatei
