import os
from dotenv import load_dotenv

load_dotenv()

# Bybit API
API_KEY = os.getenv("BYBIT_API_KEY")
API_SECRET = os.getenv("BYBIT_API_SECRET")
TESTNET = os.getenv("BYBIT_TESTNET", "true").lower() == "true"

# Trading pairs
SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]

# Risk settings
LEVERAGE = 10
MAX_POSITION_USDT = 150
STOP_LOSS_PCT = 0.15    # 15%
TAKE_PROFIT_PCT = 0.30  # 30%

# Strategy settings
EMA_FAST = 9
EMA_SLOW = 21
RSI_PERIOD = 14
RSI_MIN = 40
RSI_MAX = 65

# Candle interval (in minutes)
INTERVAL = "15"  # 15-minute candles

# How often the bot checks (seconds)
CHECK_INTERVAL = 60
