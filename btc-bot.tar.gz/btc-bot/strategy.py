import pandas as pd
import ta
from config import EMA_FAST, EMA_SLOW, RSI_PERIOD, RSI_MIN, RSI_MAX


def calculate_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Add EMA and RSI indicators to dataframe."""
    df["ema_fast"] = ta.trend.ema_indicator(df["close"], window=EMA_FAST)
    df["ema_slow"] = ta.trend.ema_indicator(df["close"], window=EMA_SLOW)
    df["rsi"] = ta.momentum.rsi(df["close"], window=RSI_PERIOD)
    return df


def get_signal(df: pd.DataFrame) -> dict:
    """
    Returns signal dict:
    - signal: 'long', 'short', or None
    - strength: 0.0–1.0 (higher = stronger signal)
    - reason: human-readable explanation
    """
    df = calculate_indicators(df)
    latest = df.iloc[-1]
    prev = df.iloc[-2]

    ema_cross_up = prev["ema_fast"] <= prev["ema_slow"] and latest["ema_fast"] > latest["ema_slow"]
    ema_cross_down = prev["ema_fast"] >= prev["ema_slow"] and latest["ema_fast"] < latest["ema_slow"]
    rsi_ok_long = RSI_MIN <= latest["rsi"] <= RSI_MAX
    rsi_ok_short = (100 - RSI_MAX) <= (100 - latest["rsi"]) <= (100 - RSI_MIN)

    # Calculate signal strength (how far RSI is from boundaries = cleaner signal)
    rsi_center = (RSI_MIN + RSI_MAX) / 2
    rsi_strength = 1.0 - abs(latest["rsi"] - rsi_center) / (rsi_center - RSI_MIN)
    rsi_strength = max(0.0, min(1.0, rsi_strength))

    # EMA distance as additional strength indicator
    ema_diff = abs(latest["ema_fast"] - latest["ema_slow"]) / latest["ema_slow"]
    ema_strength = min(1.0, ema_diff * 100)  # normalize

    strength = (rsi_strength + ema_strength) / 2

    if ema_cross_up and rsi_ok_long:
        return {
            "signal": "long",
            "strength": round(strength, 3),
            "reason": f"EMA{EMA_FAST} crossed above EMA{EMA_SLOW}, RSI={latest['rsi']:.1f}",
            "price": latest["close"],
            "rsi": latest["rsi"],
        }
    elif ema_cross_down and rsi_ok_short:
        return {
            "signal": "short",
            "strength": round(strength, 3),
            "reason": f"EMA{EMA_FAST} crossed below EMA{EMA_SLOW}, RSI={latest['rsi']:.1f}",
            "price": latest["close"],
            "rsi": latest["rsi"],
        }

    return {"signal": None, "strength": 0.0, "reason": "No signal", "price": latest["close"], "rsi": latest["rsi"]}


def pick_best_signal(signals: dict) -> tuple[str, dict] | tuple[None, None]:
    """
    Given signals for multiple symbols, pick the one with the strongest signal.
    Returns (symbol, signal_dict) or (None, None).
    """
    candidates = [(sym, sig) for sym, sig in signals.items() if sig["signal"] is not None]
    if not candidates:
        return None, None
    # Sort by strength descending
    candidates.sort(key=lambda x: x[1]["strength"], reverse=True)
    return candidates[0]
