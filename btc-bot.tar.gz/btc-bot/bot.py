#!/usr/bin/env python3
"""
BTC/ETH/SOL Trading Bot — Bybit
Strategy: EMA 9/21 Crossover + RSI Filter
"""

import time
import logging
from datetime import datetime

from config import SYMBOLS, INTERVAL, CHECK_INTERVAL, STOP_LOSS_PCT, TAKE_PROFIT_PCT
from exchange import get_client, get_candles, get_open_positions, place_order
from strategy import get_signal, pick_best_signal

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("bot.log"),
    ],
)
log = logging.getLogger(__name__)


def scan_all_symbols(client) -> dict:
    """Scan all symbols and return signals."""
    signals = {}
    for symbol in SYMBOLS:
        try:
            df = get_candles(client, symbol, INTERVAL)
            sig = get_signal(df)
            signals[symbol] = sig
            log.info(f"  {symbol}: {sig['signal'] or 'no signal'} | RSI={sig['rsi']:.1f} | strength={sig['strength']:.3f} | {sig['reason']}")
        except Exception as e:
            log.error(f"  {symbol}: Error fetching data — {e}")
    return signals


def has_open_position(client) -> bool:
    """Check if we have any open positions across all symbols."""
    for symbol in SYMBOLS:
        positions = get_open_positions(client, symbol)
        if positions:
            log.info(f"  Open position found: {symbol}")
            return True
    return False


def run():
    log.info("=" * 50)
    log.info("Trading Bot Started")
    log.info(f"Symbols: {', '.join(SYMBOLS)}")
    log.info(f"Leverage: 10x | Max: $150 | SL: 15% | TP: 30%")
    log.info("=" * 50)

    client = get_client()

    while True:
        try:
            log.info(f"\n🔍 Scanning markets — {datetime.now().strftime('%H:%M:%S')}")

            # Skip if already in a trade
            if has_open_position(client):
                log.info("⏳ Already in a position — skipping scan")
                time.sleep(CHECK_INTERVAL)
                continue

            # Scan all symbols
            signals = scan_all_symbols(client)

            # Pick the best signal
            best_symbol, best_signal = pick_best_signal(signals)

            if best_symbol:
                log.info(f"\n✅ Best signal: {best_symbol} — {best_signal['signal'].upper()} (strength={best_signal['strength']:.3f})")
                log.info(f"   Reason: {best_signal['reason']}")

                order = place_order(
                    client=client,
                    symbol=best_symbol,
                    side=best_signal["signal"],
                    price=best_signal["price"],
                    stop_loss_pct=STOP_LOSS_PCT,
                    take_profit_pct=TAKE_PROFIT_PCT,
                )
                log.info(f"🚀 Order placed!")
                log.info(f"   Symbol:      {order['symbol']}")
                log.info(f"   Side:        {order['side'].upper()}")
                log.info(f"   Qty:         {order['qty']}")
                log.info(f"   Entry:       ${order['entry_price']:,.2f}")
                log.info(f"   Stop Loss:   ${order['stop_loss']:,.2f}")
                log.info(f"   Take Profit: ${order['take_profit']:,.2f}")
                log.info(f"   Order ID:    {order['order_id']}")
            else:
                log.info("💤 No signal — waiting...")

        except KeyboardInterrupt:
            log.info("\n⛔ Bot stopped by user.")
            break
        except Exception as e:
            log.error(f"❌ Unexpected error: {e}")

        time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    run()
